function [sigma] = WhiteNoise(gridSize, sigmaScalar)

sigma = sigmaScalar * ones(gridSize, gridSize);

end